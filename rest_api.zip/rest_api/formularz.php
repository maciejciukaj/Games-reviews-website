<?php
      
require_once("funkcje.php");
require_once("klasy/user.php");

session_start();

if(!isset($_SESSION['loged']))
{
	header('Location: index.php');
	exit();
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Recenzje</title>
        <link rel="stylesheet" href="CSS/style.css">
	</head>
	<body>
        <div class="navbar">
            <a href="glowna.php">Ranking</a>
            <a href="formularz.php">Dodaj recenzję</a>
        </div>

        <div class="formularz">
            <form action="dodajrev.php" method="post">
                </br>
                <p>Gra:</p>
                <?php
                echo listOfGames();
                ?>
                <?php
                    $zaw = "";
                    if($_SESSION['user']->getStatus() == 1 || $_SESSION['user']->getStatus() == 2)
                        $zaw = "<input type='submit' name='dodaj' value='[+]'>";
                    echo $zaw;
                ?>
		
                </br></br>
                <label for="tresc">Recenzja:</label></br>
                <textarea name='tresc'></textarea></br></br>
                <fieldset>
                    <legend>Ocena gry:</legend>

                    <input type="radio" id="1" name="ocena" value="1" checked>
                    <label for="1">1</label>
           
                    <input type="radio" id="2" name="ocena" value="2">
                    <label for="2">2</label>
         
                    <input type="radio" id="3" name="ocena" value="3">
                    <label for="3">3</label>

                    <input type="radio" id="4" name="ocena" value="4">
                    <label for="4">4</label>

                    <input type="radio" id="5" name="ocena" value="5">
                    <label for="5">5</label>

                    <input type="radio" id="6" name="ocena" value="6">
                    <label for="6">6</label>

                    <input type="radio" id="7" name="ocena" value="7">
                    <label for="7">7</label>

                    <input type="radio" id="8" name="ocena" value="8">
                    <label for="8">8</label>

                    <input type="radio" id="9" name="ocena" value="9">
                    <label for="9">9</label>

                    <input type="radio" id="10" name="ocena" value="10">
                    <label for="10">10</label>

                </fieldset>

                <input type="submit" name="submit" value="Submit">
            </form>
        </div>
	</body>
</html>
