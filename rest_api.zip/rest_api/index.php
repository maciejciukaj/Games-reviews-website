<?php
session_start();
if((isset($_SESSION['loged']))&&($_SESSION['loged']==true))
{
	header('Location: glowna.php');
	exit();
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Recenzje</title>
	</head>
	<body>
		<?php
			require_once("funkcje.php");
			login();
			if(isset($_SESSION['blad']))
			{
				echo $_SESSION['blad'];
				unset($_SESSION['blad']);
			}
		?>
	</body>
</html>
