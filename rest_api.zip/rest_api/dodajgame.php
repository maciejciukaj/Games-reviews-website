<?php
require_once("klasy/baza.php");
require_once("funkcje.php");

if (isset($_POST['submit'])) {

	$nazwa = $_POST['nazwa'];
	$gatunek = $_POST['gatunek'];
	$date = $_POST['date'];
	$wydawca = $_POST['wydawca'];

	$db = new Baza("localhost", "root", "", "recenzje");
	
	$sql = "INSERT INTO `games`(`name`, `genre`, `data`, `publisher`) VALUES ('$nazwa','$gatunek','$date','$wydawca')";

	if (@$db->zapytanie($sql)) {
		header('location:glowna.php');
		exit();
	} else {
		echo "Error!";
		echo $date;
	}
}
