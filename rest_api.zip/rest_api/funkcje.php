<?php

require_once("klasy/baza.php");
require_once("klasy/game.php");
require_once("klasy/user.php");
require_once("klasy/review.php");



function dbGetUsers()
{
	$bb = new Baza("localhost", "root", "", "recenzje");
	$sqlGames = "SELECT * FROM users";

    	if (($rezultat_game = @$bb->select($sqlGames)) != 0) {
		$rezultat = array_values($rezultat_game);
        	$users = [];
		
        	for ($i = 1; $i < count($rezultat); $i++) {	
            		array_push($users, new User($rezultat[$i]["Login"], $rezultat[$i]["Email"], $rezultat[$i]["Haslo"], $rezultat[$i]["Status"]));
        	}
		//echo var_dump($games);
		return $users;
	}
	else
	{
		echo "Error:Brak dostepu do bazy danych!";
		return 0;
	}
}

function dbGetRecenzje()
{
	$db = new Baza("localhost", "root", "", "recenzje");
	$sqlRewievs = "SELECT * FROM reviews";
	if (($rezultat = @$db->select($sqlRewievs)) != 0) {
            $reviews = [];
//echo "</br></br>";
//echo var_dump($rezultat);
//echo "</br></br>";
            for ($i = 1; $i < count($rezultat); $i++) {
                array_push($reviews, new Review($rezultat[$i]["id_review"], $rezultat[$i]["body"], $rezultat[$i]["user"], $rezultat[$i]["rate"], $rezultat[$i]["game_name"]));
            }

            $_SESSION['recenzje'] = $reviews;
		return $reviews;

        }
	else
	{
		echo "Error:Brak dostepu do bazy danych!";
		return 0;
	}
	
}



function dbGetGames()
{

	$bb = new Baza("localhost", "root", "", "recenzje");
	$sqlGames = "SELECT * FROM games";

    	if (($rezultat_game = @$bb->select($sqlGames)) != 0) {
		$rezultat = array_values($rezultat_game);
        	$games = [];
		
        	for ($i = 1; $i < count($rezultat); $i++) {	
            		array_push($games, new Game($rezultat[$i]["name"], $rezultat[$i]["genre"], $rezultat[$i]["data"], $rezultat[$i]["publisher"]));
        	}
		//echo var_dump($games);
		return $games;
	}
	else
	{
		echo "Error:Brak dostepu do bazy danych!";
		return 0;
	}
	
	
}

function getGameRates()
{
	$games=dbGetGames();
	$reviews=dbGetRecenzje();
	//echo var_dump($reviews);
    for ($i = 0; $i < count($games); $i++) {
        $games[$i]->calculateRate($reviews);
    }
    $_SESSION['gry'] = $games;
    $zawartosc = "<div>Witaj ".$_SESSION['user']->getLogin()."!<div><ul>";
    for ($i = 0; $i < count($games); $i++) {
        $zawartosc .= "<li>"."<a href='szczegolyGry.php?id=".$games[$i]->getName()."'>" . $games[$i]->getName() . " ||| " . number_format($games[$i]->getAvg(), 2) . "/10.00</a></li>";
    }
    $zawartosc .= "</ul>";

	if($_SESSION['user']->getStatus() == 2)
		$zawartosc .="<div><a href='uzytkownicy.php'>Zarządzaj użytkownikami</a></div>";

	$zawartosc .= "<div><a href='wyloguj.php'>Wyloguj</a></div>";

    return $zawartosc;
}


function listOfGames()
{
    $zawartosc = "<select name='gra'>";

    $games = $_SESSION['gry'];

    for ($i = 0; $i < count($games); $i++) {
        $zawartosc .= "<option value=\"" . $games[$i]->getName() . "\">".$games[$i]->getName()."</option>";
    }

    $zawartosc .= "</select>";
    return $zawartosc;
}

function getReviews($id)
{
	//$games=dbGetGames();
	$reviews=dbGetRecenzje();
	$reviewsOfGame=[];	
	$zawartosc = "<table>";
	for ($i = 0; $i < count($reviews); $i++) {
		if($reviews[$i]->getId_game() == $id)
		{
			$zawartosc .= "<tr>";
			$zawartosc .= "<th>".$reviews[$i]->getUser().":</th>";
			$zawartosc .= "<th>\t".$reviews[$i]->getBody()."</th>";
			$zawartosc .= "</tr>";
			$zawartosc .= "<tr>";
			$zawartosc .= "<th></th>";
			$zawartosc .= "<th>".$reviews[$i]->getRate()."/10</br></th>";
			$zawartosc .= "</tr>";
		}
    	}
	$zawartosc .= "</table>";
	return $zawartosc;
}


function login()
	{
		?>
		<h1>Logowanie</h1>
		<form action='zaloguj.php' method="post">
			<table>
				<tr>
					<th>login:</th>
					<th><input type='text' name='login' /></th>
				</tr>
				<tr>
					<th>password:</th>
					<th><input type='password' name='password' /></th>
				</tr>
				<tr>
					<th colspan='2'><input type='submit' name='zaloguj' value='Zaloguj'/></th>
				</tr>
				<tr>
					<th colspan='2'></br><input type='submit' name='rejestracja' value='Nie mam konta'/></th>
				</tr>
			</table>
		</form> <?php
	}

	function getUserslist()
	{
		$users=dbGetUsers();
		$zawartosc = "<form  action='aktualizuj.php' method='post'><table>";
		for ($i = 0; $i < count($users); $i++) {
			if($users[$i]->getStatus()== 2){}
			else{
				if($users[$i]->getStatus()== 1)
				{
					$status="Admin";
				}
				else
				{
					$status="Użytkownik";
				}

				$zawartosc .= "<tr>";
				$zawartosc .= "<th>".$users[$i]->getLogin().":</th>";
				$zawartosc .= "<th>".$users[$i]->getHaslo()."</th>";
				$zawartosc .= "<th>".$users[$i]->getEmail()."</th>";
				$zawartosc .= "<th>".$status."</th>";
				$zawartosc .= "<th><input type='submit' name='akt".$i."' value='Aktualizuj Status'></th>";
				$zawartosc .= "<th><input type='submit' name='us".$i."' value='Usuń'></th>";
				$zawartosc .= "</tr>";
			}	
			
			
    	}
		$zawartosc .= "</table></form>";
		return $zawartosc;
	}
