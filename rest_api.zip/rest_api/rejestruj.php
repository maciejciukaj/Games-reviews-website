<?php
require_once("klasy/baza.php");
require_once("funkcje.php");
require_once("klasy/user.php");

session_start();


if(!isset($_POST['logowanie']))
{
	if(isset($_POST['email']) && isset($_POST['login']) && isset($_POST['password']) && isset($_POST['password2']))
	{
		$args = ['login' => ['filter' => FILTER_VALIDATE_REGEXP,
				'options' => ['regexp' => '/^[A-Za-z0-9]{3,10}$/']
								],
					'email' => ['filter' => FILTER_VALIDATE_EMAIL],
					'password' => ['filter' => FILTER_VALIDATE_REGEXP,
				'options' => ['regexp' => '/^\S*(?=\S{5,15})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])\S*$/']]
			];
			
			$dane = filter_input_array(INPUT_POST, $args);
			//var_dump($dane);
			if($dane['password'] != false)
			{
				if($dane['login'] != false)
				{
					if($dane['email'] != false)
					{
						if($dane['password'] === $_POST['password2'])
						{
							$db = new Baza("localhost", "root", "", "recenzje");
							$login1=$_POST['login'];
							$sql = "SELECT * FROM users WHERE Login='$login1'";
							if(!(($rezultat = @$db->select($sql)) != 0))
							{
								echo $dane['login'];
								$_SESSION['newLogin']=$dane['login'];
								$_SESSION['newHaslo']=$dane['password'];
								//$_SESSION['newHaslo']=password_hash($dane['password'], PASSWORD_DEFAULT);
								$_SESSION['newEmail']=$dane['email'];
								echo $_SESSION['newLogin'];
								header('location: zaloguj.php');
								exit();
							}
							else
							{
								$_SESSION['validacja']="<span style='color:red'>Podany login już istnieje w bazie danych!</br>
							</span>";
							}
						}
						else
						{
							$_SESSION['validacja']="<span style='color:red'>Niepasujace hasło!</br>
							</span>";
		
						}
					}
					else
					{
						$_SESSION['validacja']="<span style='color:red'>Niepoprawny email!</br>
						</span>";

					}
				}
				else
				{
					$_SESSION['validacja']="<span style='color:red'>Niepoprawny login!</br>
					*od 3 do 15 znaków
					*login składa się z małych, dużych liter i cyfr
					</span>";
					
				}
			}
			else
			{
				$_SESSION['validacja']="<span style='color:red'>Niepoprawne hasło!</br>
				*od 5 do 15 znaków
				*haslo musi zawierac chociaż po jednej małej,duże literze i czyfrze
				</span>";
				
			}
	}
	else
	{
		/*$_SESSION['validacja']="<span style='color:red'>Uzupełnij wszystkie pola!</br>
			</span>";*/
	}
}
else
{
	header('location:index.php');
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Rejestruj</title>
	</head>
	<body>
		<h1>Rejestracja</h1>
		<form method="post">
			<table>
				<tr>
					<th>Email:</th>
					<th><input type='text' name='email' /></th>
				</tr>
				<tr>
					<th>Login:</th>
					<th><input type='text' name='login' /></th>
				</tr>
				<tr>
					<th>Hasło:</th>
					<th><input type='password' name='password' /></th>
				</tr>
				<tr>
					<th>Powtórz hasło:</th>
					<th><input type='password' name='password2' /></th>
				</tr>
				<tr>
					<th colspan='2'></br><input type='submit' name='rejestruj' value='Zarejestruj'/></th>
				</tr>
				<tr>
					<th colspan='2'></br><input type='submit' name='logowanie' value='Mam konto'/></th>
				</tr>
			</table>
			<?php 
				if(isset($_SESSION['validacja'])) 
				{
					echo $_SESSION['validacja'];
					unset($_SESSION['validacja']);
				}
			?>
			
		</form>
	</body>
</html>
