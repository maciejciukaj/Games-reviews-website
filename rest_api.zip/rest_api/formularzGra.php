<?php
      
require_once("funkcje.php");

session_start();

if(!isset($_SESSION['loged']))
{
	header('Location: index.php');
	exit();
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Recenzje</title>
        	<link rel="stylesheet" href="CSS/style.css">
	</head>
	<body>
        <div class="navbar">
            <a href="glowna.php">Ranking</a>
            <a href="formularz.php">Dodaj recenzję</a>
        </div>

        <div class="formularz">
            <form action="dodajgame.php" method="post">
                <label for="nazwa">Nazwa gry:</label></br>
                <input type="text" name='nazwa'></input></br></br>
                <label for="gatunek">Gatunek:</label></br>
                <input type="text" name="gatunek"></input></br></br>
		<label for="date">Data wydania:</label></br>
                <input type="date" name="date" value="2020-01-01"></input></br></br>
		<label for="wydawca">Wydawca:</label></br>
                <input type="text" name="wydawca"></input></br></br>
                <input type="submit" name="submit" value="Submit">
            </form>
        </div>
	</body>
</html>
