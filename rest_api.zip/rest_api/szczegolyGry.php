<?php       
require_once("funkcje.php");
//session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Recenzje</title>
        <link rel="stylesheet" href="CSS/style.css">
	</head>
	<body>
        <div class="navbar">
            <a href="index.php">Ranking</a>
            <a href="formularz.php">Dodaj recenzję</a>
        </div>
        <div class="recenzje">
            <?php
            
            	echo getReviews($_GET['id']);
            
            ?>
        </div>
	</body>
</html>
