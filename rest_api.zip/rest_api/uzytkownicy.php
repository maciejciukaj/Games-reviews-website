<?php       
require_once("funkcje.php");
session_start();
if(!isset($_SESSION['loged']) || $_SESSION['user']->getStatus() != 2)
{
	header('Location: index.php');
	exit();
}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Recenzje</title>
        <link rel="stylesheet" href="CSS/style.css">
	</head>
	<body>
        <div class="navbar">
            <a href="glowna.php">Ranking</a>
            <a href="formularz.php">Dodaj recenzję</a>
        </div>
        <div class="recenzje">
            <?php
            
            echo getUserslist();
            
            ?>
        </div>
	</body>
</html>